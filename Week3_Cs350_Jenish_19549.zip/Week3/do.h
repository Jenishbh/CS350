// do.h
#ifndef __DO_H__
#define __DO_H__

void do_student_prompt(void);
void do_list_all_students(void);

#endif